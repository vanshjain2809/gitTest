def SampleFunction():
    print ("Vansh Jain")
